"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { User, Phone, Mail, Calendar, Upload, FileText, ImageIcon, X, Save, ArrowLeft } from "lucide-react"
import { toast } from "sonner"

interface UploadedFile {
  id: string
  name: string
  size: string
  type: string
  file: File
}

export default function NewPatientPage() {
  // N8N Configuration
  const N8N_WEBHOOK_URL = process.env.NEXT_PUBLIC_N8N_WEBHOOK_URL || "http://localhost:5678/webhook-test/patient-data"
  const N8N_API_KEY = process.env.NEXT_PUBLIC_N8N_API_KEY
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([])
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    dateOfBirth: "",
    gender: "",
    address: "",
    emergencyContact: "",
    emergencyPhone: "",
    medicalHistory: "",
    allergies: "",
    currentMedications: "",
  })

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files
    if (!files) return

    Array.from(files).forEach((file) => {
      const newFile: UploadedFile = {
        id: Math.random().toString(36).substr(2, 9),
        name: file.name,
        size: (file.size / 1024 / 1024).toFixed(2) + " MB",
        type: file.type.includes("image") ? "image" : file.type.includes("pdf") ? "pdf" : "document",
        file: file,
      }
      setUploadedFiles((prev) => [...prev, newFile])
    })

    // Reset input
    event.target.value = ""
  }

  const removeFile = (fileId: string) => {
    setUploadedFiles((prev) => prev.filter((file) => file.id !== fileId))
  }

  const getFileIcon = (type: string) => {
    switch (type) {
      case "image":
        return <ImageIcon className="h-4 w-4" />
      case "pdf":
        return <FileText className="h-4 w-4" />
      default:
        return <FileText className="h-4 w-4" />
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      // Validate required fields
      if (!formData.firstName || !formData.lastName || !formData.phone) {
        toast.error("Champs requis manquants", {
          description: "Veuillez remplir au minimum le prénom, nom et téléphone.",
        })
        setIsLoading(false)
        return
      }

      // Prepare the complete patient data including uploaded files info
      const patientData = {
        timestamp: new Date().toISOString(),
        action: "create_patient",
        patientInfo: {
          ...formData,
          fullName: `${formData.firstName} ${formData.lastName}`,
          age: formData.dateOfBirth ? new Date().getFullYear() - new Date(formData.dateOfBirth).getFullYear() : null,
        },
        documents: uploadedFiles.map((file) => ({
          id: file.id,
          name: file.name,
          size: file.size,
          type: file.type,
          uploadedAt: new Date().toISOString(),
        })),
        metadata: {
          createdBy: "MediRecord System",
          source: "patient-registration-form",
          documentsCount: uploadedFiles.length,
          hasEmergencyContact: !!(formData.emergencyContact && formData.emergencyPhone),
          hasMedicalHistory: !!formData.medicalHistory,
          formVersion: "1.0",
        },
      }

      // Log the data being sent
      console.log("=== SENDING PATIENT DATA TO N8N ===")
      console.log("URL:", N8N_WEBHOOK_URL)
      console.log("Data:", JSON.stringify(patientData, null, 2))
      console.log("Data size:", JSON.stringify(patientData).length, "characters")

      const headers: Record<string, string> = {
        "Content-Type": "application/json",
        Accept: "application/json",
      }

      // Add API key if available
      if (N8N_API_KEY) {
        headers["Authorization"] = `Bearer ${N8N_API_KEY}`
      }

      // const response = await fetch(N8N_WEBHOOK_URL, {
      //   method: "POST",
      //   headers,
      //   body: JSON.stringify(patientData),
      //   mode: "cors",
      // })

      const handleSubmit = async (e: React.FormEvent) => {
      e.preventDefault()
      setIsLoading(true)

      // … your validation …

      // Build the same `patientData` object, but instead of sending to N8N webhook,
      // send to Django API:
      const payload = {
        firstName: formData.firstName,
        lastName: formData.lastName,
        email: formData.email,
        phone: formData.phone,
        dateOfBirth: formData.dateOfBirth,
        gender: formData.gender,
        address: formData.address,
        emergencyContact: formData.emergencyContact,
        emergencyPhone: formData.emergencyPhone,
        medicalHistory: formData.medicalHistory,
        allergies: formData.allergies,
        currentMedications: formData.currentMedications,
        // (we don’t send uploadedFiles here; you can upload them separately or include them if you store file metadata)
      }

      try {
        const response = await fetch("/api/patients/", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(payload),
          mode: "cors",
        })

        if (!response.ok) {
          const errText = await response.text()
          throw new Error(`Django API error: ${response.status} ${errText}`)
        }

        const data = await response.json()
        console.log("Patient created, activation link:", data.activation_link)
        toast.success("Patient créé avec succès !", {
          description: "Un SMS/WhatsApp d’activation sera envoyé au patient.",
        })

        // Optionally redirect after a short delay:
        setTimeout(() => {
          router.push("/dashboard/patients")
        }, 1000)
      } catch (error) {
        console.error("Error creating patient via Django:", error)
        toast.error("Erreur lors de la création", {
          description: `Erreur: ${error instanceof Error ? error.message : "Inconnue"}`,
        })
      } finally {
        setIsLoading(false)
      }
    }


      // console.log("=== N8N RESPONSE ===")
      // console.log("Status:", response.status)
      // console.log("Status Text:", response.statusText)
      // console.log("Headers:", Object.fromEntries(response.headers.entries()))

      // if (!response.ok) {
      //   const errorText = await response.text()
      //   console.error("N8N Error response:", errorText)
      //   throw new Error(`N8N request failed: ${response.status} ${response.statusText} - ${errorText}`)
      // }

      // const n8nResponse = await response.text()
      // console.log("N8N Response Body:", n8nResponse)

      // Show success message
      toast.success("Patient créé avec succès", {
        description: "Le profil patient a été créé et envoyé à N8N pour traitement automatique.",
      })

      // Navigate to the patients page after a short delay
      setTimeout(() => {
        router.push("/dashboard/patients")
      }, 1000)
    } catch (error) {
      console.error("=== ERROR SENDING DATA TO N8N ===", error)

      let errorMessage = "Erreur inconnue"
      if (error instanceof TypeError && error.message.includes("fetch")) {
        errorMessage = "Impossible de se connecter à N8N. Vérifiez que N8N est démarré sur localhost:5678"
      } else if (error instanceof Error) {
        errorMessage = error.message
      }

      toast.error("Erreur lors de la création", {
        description: `Erreur lors de l'envoi des données à N8N: ${errorMessage}`,
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Function to get the current patient data in JSON format
  const getPatientDataJson = () => {
    const patientData = {
      ...formData,
      documents: uploadedFiles.map((file) => ({
        id: file.id,
        name: file.name,
        size: file.size,
        type: file.type,
      })),
    }
    return JSON.stringify(patientData, null, 2)
  }

  // Function to simulate an API endpoint that returns the patient data
  const getPatientDataApi = () => {
    // In a real application, this would be an actual API endpoint
    return {
      endpoint: "/api/patients/new",
      method: "POST",
      requestBody: {
        ...formData,
        documents: uploadedFiles.map((file) => ({
          id: file.id,
          name: file.name,
          size: file.size,
          type: file.type,
        })),
      },
      responseFormat: "application/json",
    }
  }

  const testN8NConnection = async () => {
    try {
      console.log("Testing N8N connection to:", N8N_WEBHOOK_URL)

      const testData = {
        test: true,
        message: "Test connection from MediRecord",
        timestamp: new Date().toISOString(),
      }

      const headers: Record<string, string> = {
        "Content-Type": "application/json",
      }

      // Add API key if available
      if (N8N_API_KEY) {
        headers["Authorization"] = `Bearer ${N8N_API_KEY}`
      }

      const response = await fetch(N8N_WEBHOOK_URL, {
        method: "POST",
        headers,
        body: JSON.stringify(testData),
        mode: "cors",
      })

      console.log("N8N Response status:", response.status)
      console.log("N8N Response headers:", Object.fromEntries(response.headers.entries()))

      if (response.ok) {
        const responseData = await response.text()
        console.log("N8N Response data:", responseData)
        toast.success("Connexion N8N réussie", {
          description: "La connexion avec N8N fonctionne correctement.",
        })
      } else {
        const errorText = await response.text()
        console.error("N8N Error details:", errorText)
        throw new Error(`Status: ${response.status} - ${response.statusText} - ${errorText}`)
      }
    } catch (error) {
      console.error("N8N Connection error:", error)

      let errorMessage = "Erreur inconnue"
      if (error instanceof TypeError && error.message.includes("fetch")) {
        errorMessage = "Impossible de se connecter à N8N. Vérifiez que N8N est démarré sur localhost:5678"
      } else if (error instanceof Error) {
        errorMessage = error.message
      }

      toast.error("Erreur de connexion N8N", {
        description: `Impossible de se connecter à N8N: ${errorMessage}`,
      })
    }
  }

  const testWithSampleData = async () => {
    try {
      console.log("Testing with sample patient data...")

      const samplePatientData = {
        timestamp: new Date().toISOString(),
        action: "create_patient",
        patientInfo: {
          firstName: "Jean",
          lastName: "Dupont",
          email: "jean.dupont@example.com",
          phone: "+221 77 123 45 67",
          dateOfBirth: "1990-01-15",
          gender: "male",
          address: "123 Rue de la Paix, Dakar",
          emergencyContact: "Marie Dupont",
          emergencyPhone: "+221 77 987 65 43",
          medicalHistory: "Aucun antécédent particulier",
          allergies: "Aucune allergie connue",
          currentMedications: "Aucun médicament",
          fullName: "Jean Dupont",
          age: 34,
        },
        documents: [
          {
            id: "sample123",
            name: "ordonnance_sample.pdf",
            size: "2.5 MB",
            type: "pdf",
            uploadedAt: new Date().toISOString(),
          },
        ],
        metadata: {
          createdBy: "MediRecord System",
          source: "patient-registration-form",
          documentsCount: 1,
          hasEmergencyContact: true,
          hasMedicalHistory: true,
          formVersion: "1.0",
        },
      }

      const headers: Record<string, string> = {
        "Content-Type": "application/json",
      }

      if (N8N_API_KEY) {
        headers["Authorization"] = `Bearer ${N8N_API_KEY}`
      }

      console.log("Sending sample data:", JSON.stringify(samplePatientData, null, 2))

      const response = await fetch(N8N_WEBHOOK_URL, {
        method: "POST",
        headers,
        body: JSON.stringify(samplePatientData),
        mode: "cors",
      })

      console.log("Sample data response status:", response.status)

      if (response.ok) {
        const responseData = await response.text()
        console.log("Sample data response:", responseData)
        toast.success("Test avec données échantillon réussi", {
          description: "Les données échantillon ont été envoyées avec succès à N8N.",
        })
      } else {
        const errorText = await response.text()
        throw new Error(`Status: ${response.status} - ${errorText}`)
      }
    } catch (error) {
      console.error("Sample data test error:", error)
      toast.error("Erreur test données échantillon", {
        description: `Erreur: ${error instanceof Error ? error.message : "Erreur inconnue"}`,
      })
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-4">
        <Button variant="ghost" size="icon" onClick={() => router.back()}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-slate-900 dark:text-white">Nouveau patient</h1>
          <p className="text-slate-600 dark:text-slate-400">
            Créez un nouveau profil patient avec ses documents médicaux
          </p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Informations personnelles */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <User className="mr-2 h-5 w-5" />
                  Informations personnelles
                </CardTitle>
                <CardDescription>Renseignez les informations de base du patient</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="firstName">Prénom *</Label>
                    <Input
                      id="firstName"
                      value={formData.firstName}
                      onChange={(e) => handleInputChange("firstName", e.target.value)}
                      placeholder="Prénom du patient"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lastName">Nom *</Label>
                    <Input
                      id="lastName"
                      value={formData.lastName}
                      onChange={(e) => handleInputChange("lastName", e.target.value)}
                      placeholder="Nom du patient"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                      <Input
                        id="email"
                        type="email"
                        value={formData.email}
                        onChange={(e) => handleInputChange("email", e.target.value)}
                        placeholder="email@exemple.com"
                        className="pl-10"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Téléphone *</Label>
                    <div className="relative">
                      <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                      <Input
                        id="phone"
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => handleInputChange("phone", e.target.value)}
                        placeholder="+221 77 123 45 67"
                        className="pl-10"
                        required
                      />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="dateOfBirth">Date de naissance</Label>
                    <div className="relative">
                      <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                      <Input
                        id="dateOfBirth"
                        type="date"
                        value={formData.dateOfBirth}
                        onChange={(e) => handleInputChange("dateOfBirth", e.target.value)}
                        className="pl-10"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="gender">Sexe</Label>
                    <Select onValueChange={(value) => handleInputChange("gender", value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Sélectionnez le sexe" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="male">Masculin</SelectItem>
                        <SelectItem value="female">Féminin</SelectItem>
                        <SelectItem value="other">Autre</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="address">Adresse</Label>
                  <Input
                    id="address"
                    value={formData.address}
                    onChange={(e) => handleInputChange("address", e.target.value)}
                    placeholder="Adresse complète du patient"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="emergencyContact">Contact d'urgence</Label>
                    <Input
                      id="emergencyContact"
                      value={formData.emergencyContact}
                      onChange={(e) => handleInputChange("emergencyContact", e.target.value)}
                      placeholder="Nom du contact d'urgence"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="emergencyPhone">Téléphone d'urgence</Label>
                    <Input
                      id="emergencyPhone"
                      type="tel"
                      value={formData.emergencyPhone}
                      onChange={(e) => handleInputChange("emergencyPhone", e.target.value)}
                      placeholder="+221 77 123 45 67"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Informations médicales */}
            <Card>
              <CardHeader>
                <CardTitle>Informations médicales</CardTitle>
                <CardDescription>Antécédents médicaux et informations de santé</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="medicalHistory">Antécédents médicaux</Label>
                  <Textarea
                    id="medicalHistory"
                    value={formData.medicalHistory}
                    onChange={(e) => handleInputChange("medicalHistory", e.target.value)}
                    placeholder="Décrivez les antécédents médicaux du patient..."
                    rows={3}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="allergies">Allergies</Label>
                  <Textarea
                    id="allergies"
                    value={formData.allergies}
                    onChange={(e) => handleInputChange("allergies", e.target.value)}
                    placeholder="Listez les allergies connues du patient..."
                    rows={2}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="currentMedications">Médicaments actuels</Label>
                  <Textarea
                    id="currentMedications"
                    value={formData.currentMedications}
                    onChange={(e) => handleInputChange("currentMedications", e.target.value)}
                    placeholder="Listez les médicaments actuellement pris par le patient..."
                    rows={2}
                  />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Upload de documents */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Upload className="mr-2 h-5 w-5" />
                  Documents médicaux
                </CardTitle>
                <CardDescription>Téléchargez les documents du patient pour indexation automatique</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-6 text-center">
                  <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                  <div className="space-y-2">
                    <Label htmlFor="file-upload" className="cursor-pointer">
                      <span className="text-sm font-medium text-blue-600 hover:text-blue-500">
                        Cliquez pour télécharger
                      </span>
                      <span className="text-sm text-gray-500"> ou glissez-déposez</span>
                    </Label>
                    <Input
                      id="file-upload"
                      type="file"
                      multiple
                      accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                    <p className="text-xs text-gray-500">PDF, Images, Documents (max. 10MB par fichier)</p>
                  </div>
                </div>

                {uploadedFiles.length > 0 && (
                  <div className="space-y-2">
                    <Label>Fichiers téléchargés ({uploadedFiles.length})</Label>
                    <div className="space-y-2 max-h-60 overflow-y-auto">
                      {uploadedFiles.map((file) => (
                        <div
                          key={file.id}
                          className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg"
                        >
                          <div className="flex items-center space-x-3">
                            <div className="p-1 bg-blue-100 dark:bg-blue-900/20 rounded">{getFileIcon(file.type)}</div>
                            <div>
                              <p className="text-sm font-medium truncate max-w-[150px]">{file.name}</p>
                              <p className="text-xs text-gray-500">{file.size}</p>
                            </div>
                          </div>
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            onClick={() => removeFile(file.id)}
                            className="h-8 w-8"
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Résumé</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Documents:</span>
                    <Badge variant="outline">{uploadedFiles.length} fichier(s)</Badge>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Indexation:</span>
                    <Badge variant="secondary">Automatique</Badge>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>WhatsApp:</span>
                    <Badge variant="outline">À configurer</Badge>
                  </div>
                </div>

                <div className="pt-4 border-t border-gray-200 dark:border-gray-700 mt-4">
                  <h4 className="text-sm font-medium mb-2">N8N Integration</h4>
                  <div className="space-y-2 text-xs text-muted-foreground">
                    <div className="flex justify-between">
                      <span>Webhook URL:</span>
                      <code className="text-xs bg-gray-100 dark:bg-gray-800 px-1 rounded truncate max-w-[120px]">
                        {N8N_WEBHOOK_URL}
                      </code>
                    </div>
                    <div className="flex justify-between">
                      <span>Method:</span>
                      <code className="text-xs bg-gray-100 dark:bg-gray-800 px-1 rounded">POST/GET</code>
                    </div>
                    <div className="flex justify-between">
                      <span>Format:</span>
                      <code className="text-xs bg-gray-100 dark:bg-gray-800 px-1 rounded">JSON</code>
                    </div>
                  </div>
                  <Button type="button" variant="outline" size="sm" className="w-full mt-2" onClick={testN8NConnection}>
                    Tester connexion N8N
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    className="w-full mt-2"
                    onClick={testWithSampleData}
                  >
                    Test avec données échantillon
                  </Button>
                </div>

                <div className="pt-4 space-y-2">
                  <Button
                    type="button"
                    variant="outline"
                    className="w-full"
                    onClick={() => {
                      const jsonData = getPatientDataJson()
                      console.log("Current patient data:", JSON.parse(jsonData))
                      navigator.clipboard.writeText(jsonData).then(() => {
                        toast.success("JSON copié dans le presse-papier", {
                          description: "Les données du patient ont été copiées au format JSON.",
                        })
                      })
                    }}
                  >
                    <FileText className="mr-2 h-4 w-4" />
                    Copier JSON
                  </Button>
                  <Button
                    type="submit"
                    className="w-full gradient-bg text-slate-900 font-semibold hover:opacity-90"
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-slate-900 mr-2"></div>
                        Création en cours...
                      </>
                    ) : (
                      <>
                        <Save className="mr-2 h-4 w-4" />
                        Créer le patient
                      </>
                    )}
                  </Button>

                  <Button
                    type="button"
                    variant="outline"
                    className="w-full"
                    onClick={() => router.back()}
                    disabled={isLoading}
                  >
                    Annuler
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </form>
    </div>
  )
}
